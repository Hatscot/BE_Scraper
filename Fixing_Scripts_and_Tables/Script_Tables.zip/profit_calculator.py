"""
LEGO Profit Calculator
======================
Vergleicht BrickEconomy-Tabelle mit KA-Tracker und berechnet Profit
unter Berücksichtigung von B2C-Marge und Logistikkosten.

Eingabedateien:
  - brickeconomy_sets_*.xlsx   (Value + Growth)
  - LEGO_KA_Tracker_Result_*.xlsx  (KA Preis der Angebote)

Ausgabe: LEGO_KA_Profit_Result.xlsx (neue Datei, Originale bleiben erhalten)
"""

import pandas as pd
import re
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, numbers
from openpyxl.utils import get_column_letter
from pathlib import Path

# ─────────────────────────────────────────────
#  KONFIGURATION – hier anpassen
# ─────────────────────────────────────────────
BRICKECONOMY_FILE = "brickeconomy_sets_2026-04-19_06-41.xlsx"
KA_TRACKER_FILE   = "LEGO_KA_Tracker_Result_03.xlsx"
OUTPUT_FILE       = "LEGO_KA_Profit_Result.xlsx"

B2C_MARGIN     = 20   # %  → Verkaufspreis × 0.80
LOGISTIC_COSTS = 10   # %  → nach Marge × 0.90

# Effektiver Nettofaktor: 0.80 × 0.90 = 0.72
NET_FACTOR = (1 - B2C_MARGIN / 100) * (1 - LOGISTIC_COSTS / 100)
# ─────────────────────────────────────────────


def parse_growth(val):
    """'+311.4%'  →  3.114  |  None bei Fehler"""
    if pd.isna(val):
        return None
    s = str(val).strip().replace("%", "").replace("+", "").replace(",", ".")
    try:
        return float(s) / 100
    except ValueError:
        return None


def parse_value(val):
    """'€164.52'  →  164.52  |  None bei Fehler"""
    if pd.isna(val):
        return None
    s = str(val).strip().replace("€", "").replace(",", "").strip()
    try:
        return float(s)
    except ValueError:
        return None


def parse_ka_price(val):
    """'1250', 19, 'VB'  →  float oder None"""
    if pd.isna(val):
        return None
    s = str(val).strip().upper()
    if s in ("VB", ""):
        return None
    s = s.replace("€", "").replace(",", ".").strip()
    try:
        return float(s)
    except ValueError:
        return None


# ── Einlesen ──────────────────────────────────

be = pd.read_excel(BRICKECONOMY_FILE, sheet_name="LEGO Sets", dtype=str)
be.columns = be.columns.str.strip()

# Set Nummer bereinigen (Gruppenzeilen wie "📦 4 Juniors..." herausfiltern)
be["Set Nummer"] = be["Set Nummer"].astype(str).str.strip()
be = be[be["Set Nummer"].str.match(r"^\d+$")].copy()
be["Set Nummer"] = be["Set Nummer"].astype(int)
be["_growth"] = be["Growth"].apply(parse_growth)
be["_value"]  = be["Value (€)"].apply(parse_value)

# Lookup: Set Nummer → (growth, value)  – bei Duplikaten ersten Treffer nehmen
be_unique = be.drop_duplicates(subset="Set Nummer", keep="first")
be_lookup = be_unique.set_index("Set Nummer")[["_growth", "_value"]].to_dict("index")

ka = pd.read_excel(KA_TRACKER_FILE, sheet_name="Posteingang", dtype=str)
ka.columns = ka.columns.str.strip()

ka["Set Nummer"] = ka["Set Nummer"].astype(str).str.strip()
ka = ka[ka["Set Nummer"].str.match(r"^\d+$")].copy()
ka["Set Nummer"] = ka["Set Nummer"].astype(int)
ka["_ka_price"]  = ka["KA Preis"].apply(parse_ka_price)

# ── Berechnungen ──────────────────────────────

rows = []
for _, row in ka.iterrows():
    setnr     = row["Set Nummer"]
    ka_price  = row["_ka_price"]
    be_info   = be_lookup.get(setnr, {})
    growth    = be_info.get("_growth")
    mw        = be_info.get("_value")      # Marktwert laut BrickEconomy

    profit_eur = None
    profit_pct = None

    if ka_price and mw and ka_price > 0:
        net_revenue = mw * NET_FACTOR          # was nach Marge + Logistik bleibt
        profit_eur  = net_revenue - ka_price
        profit_pct  = (profit_eur / ka_price) * 100

    rows.append({
        "Kauf":          row.get("Kauf", ""),
        "Beobachten":    row.get("Beobachten", ""),
        "Löschen":       row.get("Löschen", ""),
        "Archiv":        row.get("Archiv", ""),
        "Set Gruppe":    row.get("Set Gruppe", ""),
        "Set Nummer":    setnr,
        "Set Name":      row.get("Set Name", ""),
        "Jahr":          row.get("Jahr", ""),
        "Marktwert (€)": mw,
        "Growth":        growth,       # als Dezimal, z.B. 3.114
        "KA Preis":      ka_price,
        "Profit (€)":    profit_eur,
        "Profit (%)":    profit_pct,
    })

result = pd.DataFrame(rows)

# ── Excel-Ausgabe mit Formatierung ────────────

result.to_excel(OUTPUT_FILE, index=False, sheet_name="KA Profit")

wb = load_workbook(OUTPUT_FILE)
ws = wb["KA Profit"]

# Farben
HEADER_BG   = "1F3864"   # Dunkelblau
HEADER_FG   = "FFFFFF"
POS_BG      = "C6EFCE"   # Grün  (Profit > 0)
NEG_BG      = "FFC7CE"   # Rot   (Profit ≤ 0)
NEUTRAL_BG  = "FFEB9C"   # Gelb  (kein Preis vorhanden)

col_map = {cell.value: cell.column for cell in ws[1]}

# Header formatieren
for cell in ws[1]:
    cell.font      = Font(name="Arial", bold=True, color=HEADER_FG)
    cell.fill      = PatternFill("solid", start_color=HEADER_BG)
    cell.alignment = Alignment(horizontal="center")

# Spaltenbreiten
widths = {
    "Kauf": 8, "Beobachten": 12, "Löschen": 10, "Archiv": 10,
    "Set Gruppe": 20, "Set Nummer": 14, "Set Name": 35, "Jahr": 8,
    "Marktwert (€)": 16, "Growth": 12, "KA Preis": 12,
    "Profit (€)": 14, "Profit (%)": 14,
}
for col_name, w in widths.items():
    if col_name in col_map:
        ws.column_dimensions[get_column_letter(col_map[col_name])].width = w

# Zahlenformat + Zeilenfarbe
profit_eur_col = col_map.get("Profit (€)")
profit_pct_col = col_map.get("Profit (%)")
mw_col         = col_map.get("Marktwert (€)")
growth_col     = col_map.get("Growth")
ka_col         = col_map.get("KA Preis")

for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
    p_eur_cell = row[profit_eur_col - 1] if profit_eur_col else None
    p_pct_cell = row[profit_pct_col - 1] if profit_pct_col else None
    mw_cell    = row[mw_col - 1]         if mw_col         else None
    gr_cell    = row[growth_col - 1]     if growth_col     else None
    ka_cell    = row[ka_col - 1]         if ka_col         else None

    # Zahlenformate
    if mw_cell and mw_cell.value is not None:
        mw_cell.number_format = '#,##0.00 "€"'
    if gr_cell and gr_cell.value is not None:
        gr_cell.number_format = '+0.0%;-0.0%;-'
    if ka_cell and ka_cell.value is not None:
        ka_cell.number_format = '#,##0.00 "€"'
    if p_eur_cell and p_eur_cell.value is not None:
        p_eur_cell.number_format = '#,##0.00 "€"'
    if p_pct_cell and p_pct_cell.value is not None:
        p_pct_cell.number_format = '+0.0%;-0.0%;-'

    # Zeilenfarbe nach Profit
    if p_eur_cell and p_eur_cell.value is not None:
        color = POS_BG if p_eur_cell.value > 0 else NEG_BG
    else:
        color = NEUTRAL_BG
    fill = PatternFill("solid", start_color=color)
    for cell in row:
        cell.fill = fill

# Infozeile Konfiguration
info_row = ws.max_row + 2
ws.cell(info_row, 1, f"Konfiguration:  B2C-Marge = {B2C_MARGIN}%  |  Logistikkosten = {LOGISTIC_COSTS}%  |  Nettofaktor = {NET_FACTOR:.4f}")
ws.cell(info_row, 1).font = Font(italic=True, color="888888")

wb.save(OUTPUT_FILE)
print(f"✅  Fertig! Ausgabe: {OUTPUT_FILE}")
print(f"   Zeilen verarbeitet : {len(result)}")
print(f"   Mit Profit-Daten   : {result['Profit (€)'].notna().sum()}")
print(f"   Profitable Angebote: {(result['Profit (€)'] > 0).sum()}")
